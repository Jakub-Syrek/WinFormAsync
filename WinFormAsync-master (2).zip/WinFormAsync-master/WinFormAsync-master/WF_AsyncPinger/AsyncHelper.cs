﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;

namespace WF_AsyncPinger
{
    static class AsyncHelper
    {
        static public bool PingSync(string _ip)
        {
            using (Ping myPing = new Ping())
            {
                PingReply _replied = myPing.Send(_ip);

                return (_replied.Status == IPStatus.Success) ? true : false;
            }
        }

        static async public Task<bool> PingAsync(string _ip)
        {
            using (Ping myPing = new Ping())
            {
                var _replied = await myPing.SendPingAsync(_ip);

                return (_replied.Status == IPStatus.Success) ? true : false;
            }
        }

        static public bool TelnetSync(string _ip, int _port)
        {
            TcpClient tcpClient = null;

            try
            {
                tcpClient = new TcpClient(_ip, _port);
                return true;
            }
            catch (SocketException)
            {
                return false;
            }
            finally
            {
                if (tcpClient != null)
                {
                    tcpClient.Close();
                }
            }
        }

        static async public Task<bool> TelnetAsync(string _ip, int _port) 
        {             

            TcpClient tcpClient = null;

            try
            {
                tcpClient = new TcpClient();

                await tcpClient.ConnectAsync(_ip, _port);

                return true;
            }
            catch (SocketException)
            {
                return false;
            }
            finally
            {
                if (tcpClient != null)
                {
                    tcpClient.Close();
                }
            }
        }

        public static IEnumerable<TracertEntry> TracertSync(string ipAddress, int maxHops, int timeout)
        {
            IPAddress address;

            // Ensure that the argument address is valid.
            if (!IPAddress.TryParse(ipAddress, out address))
                throw new ArgumentException(string.Format("{0} is not a valid IP address.", ipAddress));

            // Max hops should be at least one or else there won't be any data to return.
            if (maxHops < 1)
                throw new ArgumentException("Max hops can't be lower than 1.");

            // Ensure that the timeout is not set to 0 or a negative number.
            if (timeout < 1)
                throw new ArgumentException("Timeout value must be higher than 0.");


            Ping ping = new Ping();
            PingOptions pingOptions = new PingOptions(1, true);
            Stopwatch pingReplyTime = new Stopwatch();
            PingReply reply;

            do
            {
                pingReplyTime.Start();
                reply = ping.Send(address, timeout, new byte[] { 0 }, pingOptions);
                pingReplyTime.Stop();

                string hostname = string.Empty;
                if (reply.Address != null)
                {
                    try
                    {
#pragma warning disable CS0618 // Type or member is obsolete
                        hostname = Dns.GetHostByAddress(reply.Address).HostName;    // Retrieve the hostname for the replied address.
#pragma warning restore CS0618 // Type or member is obsolete
                    }
                    catch (SocketException) { /* No host available for that address. */ }
                }

                // Return out TracertEntry object with all the information about the hop.
                yield return new TracertEntry()
                {
                    HopID = pingOptions.Ttl,
                    Address = reply.Address == null ? "N/A" : reply.Address.ToString(),
                    Hostname = hostname,
                    ReplyTime = pingReplyTime.ElapsedMilliseconds,
                    ReplyStatus = reply.Status
                };

                pingOptions.Ttl++;
                pingReplyTime.Reset();
            }
            while (reply.Status != IPStatus.Success && pingOptions.Ttl <= maxHops);
        }
       
        public static async Task<List<TracertEntry>> TracertAsync(string ipAddress, int maxHops, int timeout)
        {

            // Ensure that the argument address is valid.
            if (!IPAddress.TryParse(ipAddress, out IPAddress address))
                throw new ArgumentException(string.Format("{0} is not a valid IP address.", ipAddress));

            // Max hops should be at least one or else there won't be any data to return.
            if (maxHops < 1)
                throw new ArgumentException("Max hops can't be lower than 1.");

            List<TracertEntry> TracertList = new List<TracertEntry>();

            // Ensure that the timeout is not set to 0 or a negative number.
            if (timeout < 1) throw new ArgumentException("Timeout value must be higher than 0.");
            Ping ping = new Ping(); PingOptions pingOptions = new PingOptions(1, true);
            Stopwatch pingReplyTime = new Stopwatch();
            PingReply reply;

            async Task<List<TracertEntry>> RunTraceRoutes() => await Task.Run(() =>
            {
                do
                {
                    pingReplyTime.Start();
                    reply = ping.Send(address, timeout, new byte[] { 0 }, pingOptions);
                    pingReplyTime.Stop();
                    string hostname = string.Empty;
                    if (reply.Address != null)
                    {
                        try
                        {
                            IPHostEntry ipHostInfo = Dns.GetHostEntry(Dns.GetHostName()); hostname = ipHostInfo.HostName;                 
                        }
                        catch (SocketException) { /* No host available for that address. */ }
                    }

                    TracertEntry tracertEntry = new TracertEntry();
                    tracertEntry.HopID = pingOptions.Ttl;
                    tracertEntry.Address = reply.Address == null ? "N/A" : reply.Address.ToString();
                    tracertEntry.Hostname = hostname;
                    tracertEntry.ReplyTime = pingReplyTime.ElapsedMilliseconds;
                    tracertEntry.ReplyStatus = reply.Status;

                    TracertList.Add(tracertEntry);

                    pingOptions.Ttl++;
                    pingReplyTime.Reset();
                }
                while (reply.Status != IPStatus.Success && pingOptions.Ttl <= maxHops);
                return  TracertList;
            });
            await RunTraceRoutes();
            return TracertList;
        }
        static public string NetstatSync(string _port)
        {
            var ip = IPGlobalProperties.GetIPGlobalProperties();
            int port = 80;
            Int32.TryParse(_port, out port);

            StringBuilder output = new StringBuilder();

            foreach (TcpConnectionInformation tcp in ip.GetActiveTcpConnections())
            {
                if (tcp.LocalEndPoint.Port == port || tcp.RemoteEndPoint.Port == port)
                {
                    output.Append($"{tcp.LocalEndPoint.Address}{Environment.NewLine}");
                    output.Append($"{tcp.RemoteEndPoint.Address}{Environment.NewLine}");
                }
            }
            return output.ToString();
        }
        static public async Task<string> NetstatAsync(string _port)
        {
            StringBuilder output = new StringBuilder();

            async Task<string> RunNetstatTask() => await Task.Run(() =>
            {
                var ip = IPGlobalProperties.GetIPGlobalProperties();
                int port = 80;
                Int32.TryParse(_port, out port);                

                foreach (TcpConnectionInformation tcp in ip.GetActiveTcpConnections())
                {
                    if (tcp.LocalEndPoint.Port == port || tcp.RemoteEndPoint.Port == port)
                    {
                        output.Append($"{tcp.LocalEndPoint.Address}{Environment.NewLine}");
                        output.Append($"{tcp.RemoteEndPoint.Address}{Environment.NewLine}");
                    }
                }
                return output.ToString();
            });
            await RunNetstatTask();
            return output.ToString();
        }
    }
}
